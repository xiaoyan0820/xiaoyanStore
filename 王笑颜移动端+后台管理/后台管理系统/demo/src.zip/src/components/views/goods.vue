<template>
    <div>
        <h1>商品管理</h1>
    </div>
</template>

<script>
export default {
    data() {
        return {

        };
    },
};
</script>

<style  lang="" scoped>

</style>
