export default {
    menuList:[],//菜单列表
    roleList:[],//角色列表
    userList:[],//管理员列表
    cateList:[],//分类列表
    specsList:[],//规格列表
}